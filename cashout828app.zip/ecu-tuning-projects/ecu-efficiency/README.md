# ECU Volumetric Efficiency Library

Advanced volumetric efficiency calculations and optimizations for engine tuning.

## Features
- VE table calculations
- Air flow modeling
- Temperature compensation
- Pressure corrections
- Real-time VE monitoring

## Building
```bash
mkdir build && cd build
cmake ..
cmake --build .
```

## Usage
```cpp
#include <ecuefficiency/calculator.hpp>

int main() {
    ECUEfficiency::Calculator calc;
    
    // Calculate VE for given conditions
    double ve = calc.calculateVE(
        rpm: 3000,
        map: 100,
        iat: 25,
        ect: 90
    );
    
    return 0;
}
``` 