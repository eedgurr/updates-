#pragma once

#include <vector>
#include <array>

namespace ECUEfficiency {

struct EngineConditions {
    double rpm;
    double map;
    double iat;
    double ect;
    double baro;
    double humidity;
};

class Calculator {
public:
    Calculator();
    ~Calculator();

    // VE calculations
    double calculateVE(const EngineConditions& conditions);
    double calculateAirMass(const EngineConditions& conditions);
    double calculateFuelMass(double airMass, double targetAFR);

    // Temperature compensation
    double compensateIAT(double iat);
    double compensateECT(double ect);

    // Pressure corrections
    double correctMAP(double map, double baro);
    double correctBarometric(double baro, double altitude);

    // Table operations
    bool setVETable(const std::vector<std::vector<double>>& table);
    bool setAirMassTable(const std::vector<std::vector<double>>& table);

private:
    class Impl;
    std::unique_ptr<Impl> pImpl;
};

} // namespace ECUEfficiency 