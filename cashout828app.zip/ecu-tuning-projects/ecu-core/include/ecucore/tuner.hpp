#pragma once

#include <string>
#include <vector>
#include <memory>
#include <functional>

namespace ECUCore {

class Tuner {
public:
    Tuner();
    ~Tuner();

    // Connection
    bool connect(const std::string& port);
    void disconnect();
    bool isConnected() const;

    // Data reading
    bool readData(std::vector<uint8_t>& data);
    bool writeData(const std::vector<uint8_t>& data);

    // Safety features
    void emergencyStop();
    bool validateChecksum(const std::vector<uint8_t>& data);
    bool createBackup(const std::string& filename);

    // Callbacks
    using DataCallback = std::function<void(const std::vector<uint8_t>&)>;
    void setDataCallback(DataCallback callback);
    void setErrorCallback(std::function<void(const std::string&)> callback);

private:
    class Impl;
    std::unique_ptr<Impl> pImpl;
};

} // namespace ECUCore 