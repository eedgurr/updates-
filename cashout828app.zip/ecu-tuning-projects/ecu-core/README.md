# ECU Core Library

Core implementation of ECU communication and basic functionality.

## Features
- Basic ECU communication protocols
- Data structures and types
- Core safety features
- Cross-platform support

## Building
```bash
mkdir build && cd build
cmake ..
cmake --build .
```

## Usage
```cpp
#include <ecucore/tuner.hpp>

int main() {
    ECUCore::Tuner tuner;
    if (tuner.connect("COM1")) {
        tuner.startMonitoring();
    }
    return 0;
}
``` 