# ECU Tuning MAUI Example

Cross-platform MAUI application demonstrating ECU tuning capabilities.

## Features
- Real-time ECU monitoring
- Map editing interface
- Data logging
- Safety features
- Cross-platform UI

## Prerequisites
- .NET 6.0 SDK
- Visual Studio 2022
- MAUI workload

## Building
```bash
# Windows
dotnet build -f net6.0-windows10.0.19041.0

# macOS
dotnet build -f net6.0-maccatalyst

# iOS
dotnet build -f net6.0-ios
```

## Usage
```csharp
using ECUTuning.Maui;

public partial class MainPage : ContentPage
{
    private readonly TunerViewModel _viewModel;

    public MainPage()
    {
        InitializeComponent();
        _viewModel = new TunerViewModel();
        BindingContext = _viewModel;
    }
}
``` 