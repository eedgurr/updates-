# ECU Scaling Library

Advanced scaling and interpolation algorithms for ECU maps and tables.

## Features
- Map scaling algorithms
- Interpolation methods
- Table optimization
- Multi-dimensional scaling
- Real-time scaling

## Building
```bash
mkdir build && cd build
cmake ..
cmake --build .
```

## Usage
```cpp
#include <ecuscaling/scaler.hpp>

int main() {
    ECUScaling::Scaler scaler;
    
    // Scale a fuel map
    scaler.scaleMap(
        inputMap: fuelMap,
        targetSize: {16, 16},
        method: ECUScaling::InterpolationMethod::Cubic
    );
    
    return 0;
}
``` 