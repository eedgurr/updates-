#pragma once

#include <vector>
#include <array>

namespace ECUScaling {

enum class InterpolationMethod {
    Linear,
    Cubic,
    Spline,
    Nearest
};

struct MapSize {
    size_t rows;
    size_t cols;
};

class Scaler {
public:
    Scaler();
    ~Scaler();

    // Map scaling
    std::vector<std::vector<double>> scaleMap(
        const std::vector<std::vector<double>>& inputMap,
        const MapSize& targetSize,
        InterpolationMethod method = InterpolationMethod::Cubic
    );

    // Table optimization
    std::vector<std::vector<double>> optimizeTable(
        const std::vector<std::vector<double>>& inputTable,
        size_t targetPoints
    );

    // Multi-dimensional scaling
    std::vector<std::vector<std::vector<double>>> scale3DMap(
        const std::vector<std::vector<std::vector<double>>>& inputMap,
        const MapSize& targetSize
    );

    // Real-time scaling
    void setScalingMethod(InterpolationMethod method);
    void setOptimizationLevel(int level);

private:
    class Impl;
    std::unique_ptr<Impl> pImpl;
};

} // namespace ECUScaling 