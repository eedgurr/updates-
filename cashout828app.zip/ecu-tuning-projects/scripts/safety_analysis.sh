#!/bin/bash

# Exit on error
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Function to check software safety features
check_software_safety() {
    print_status "Checking software safety features..."
    
    # Check for memory leaks
    if command -v valgrind >/dev/null 2>&1; then
        print_status "Running memory leak check..."
        valgrind --leak-check=full --show-leak-kinds=all ./build/ecu-tuning-interface
    else
        print_warning "Valgrind not found. Skipping memory leak check."
    fi

    # Check for undefined behavior
    if command -v clang >/dev/null 2>&1; then
        print_status "Running undefined behavior check..."
        clang -fsanitize=undefined -fno-omit-frame-pointer -g -O1 -o build/safety_test src/core/safety_test.cpp
        ./build/safety_test
    else
        print_warning "Clang not found. Skipping undefined behavior check."
    fi

    # Check for thread safety
    print_status "Checking thread safety..."
    if [ -f "src/core/thread_safety_test.cpp" ]; then
        g++ -pthread -o build/thread_test src/core/thread_safety_test.cpp
        ./build/thread_test
    else
        print_warning "Thread safety test file not found."
    fi
}

# Function to check hardware safety features
check_hardware_safety() {
    print_status "Checking hardware safety features..."
    
    # Check ECU connection
    print_status "Testing ECU connection..."
    if [ -f "src/core/can_interface.cpp" ]; then
        g++ -o build/can_test src/core/can_interface.cpp
        ./build/can_test --test-connection
    else
        print_warning "CAN interface test file not found."
    fi

    # Check voltage monitoring
    print_status "Testing voltage monitoring..."
    if [ -f "src/core/voltage_monitor.cpp" ]; then
        g++ -o build/voltage_test src/core/voltage_monitor.cpp
        ./build/voltage_test --check-levels
    else
        print_warning "Voltage monitor test file not found."
    fi

    # Check temperature monitoring
    print_status "Testing temperature monitoring..."
    if [ -f "src/core/temp_monitor.cpp" ]; then
        g++ -o build/temp_test src/core/temp_monitor.cpp
        ./build/temp_test --check-temps
    else
        print_warning "Temperature monitor test file not found."
    fi
}

# Function to check safety limits
check_safety_limits() {
    print_status "Checking safety limits..."
    
    # Check map limits
    print_status "Verifying map limits..."
    if [ -f "src/core/map_editor.cpp" ]; then
        g++ -o build/map_test src/core/map_editor.cpp
        ./build/map_test --verify-limits
    else
        print_warning "Map editor test file not found."
    fi

    # Check parameter ranges
    print_status "Verifying parameter ranges..."
    if [ -f "src/core/parameter_validator.cpp" ]; then
        g++ -o build/param_test src/core/parameter_validator.cpp
        ./build/param_test --check-ranges
    else
        print_warning "Parameter validator test file not found."
    fi
}

# Function to check emergency features
check_emergency_features() {
    print_status "Checking emergency features..."
    
    # Test emergency stop
    print_status "Testing emergency stop functionality..."
    if [ -f "src/core/emergency_stop.cpp" ]; then
        g++ -o build/emergency_test src/core/emergency_stop.cpp
        ./build/emergency_test --test-stop
    else
        print_warning "Emergency stop test file not found."
    fi

    # Test backup systems
    print_status "Testing backup systems..."
    if [ -f "src/core/backup_system.cpp" ]; then
        g++ -o build/backup_test src/core/backup_system.cpp
        ./build/backup_test --verify-backup
    else
        print_warning "Backup system test file not found."
    fi
}

# Main execution
main() {
    print_status "Starting safety analysis..."
    
    # Create build directory if it doesn't exist
    mkdir -p build
    
    # Run all safety checks
    check_software_safety
    check_hardware_safety
    check_safety_limits
    check_emergency_features
    
    print_status "Safety analysis completed!"
}

# Run main function
main 