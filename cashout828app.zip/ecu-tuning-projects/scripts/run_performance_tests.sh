#!/bin/bash

# Performance test script for ECU Tuning Interface
# Tests C++, C#, and Rust implementations

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Test parameters
ITERATIONS=1000
FILE_SIZE=1024*1024  # 1MB
THREAD_COUNTS=(1 2 4 8 16)

# Create test data
echo -e "${YELLOW}Generating test data...${NC}"
dd if=/dev/urandom of=test_data.bin bs=1M count=1

# Function to run performance test
run_test() {
    local name=$1
    local command=$2
    local results=()
    
    echo -e "${YELLOW}Running $name performance test...${NC}"
    
    for threads in "${THREAD_COUNTS[@]}"; do
        echo -e "Testing with $threads threads..."
        
        # Run test multiple times
        for ((i=1; i<=$ITERATIONS; i++)); do
            start_time=$(date +%s.%N)
            eval "$command"
            end_time=$(date +%s.%N)
            
            # Calculate duration
            duration=$(echo "$end_time - $start_time" | bc)
            results+=($duration)
        done
        
        # Calculate statistics
        sum=0
        for result in "${results[@]}"; do
            sum=$(echo "$sum + $result" | bc)
        done
        
        avg=$(echo "scale=6; $sum / $ITERATIONS" | bc)
        echo -e "${GREEN}Average time with $threads threads: $avg seconds${NC}"
    done
}

# C++ Performance Test
run_test "C++" "./cpp_hex_tuner test_data.bin"

# C# Performance Test (Windows only)
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    run_test "C#" "dotnet run --project demos/csharp/visualization/TuningInterface.csproj"
fi

# Rust Performance Test
run_test "Rust" "cargo run --release --bin safe_hex test_data.bin"

# Memory Usage Test
echo -e "${YELLOW}Testing memory usage...${NC}"

# C++ Memory Test
echo -e "${GREEN}C++ Memory Usage:${NC}"
valgrind --tool=massif ./cpp_hex_tuner test_data.bin
ms_print massif.out.* > cpp_memory.txt

# Rust Memory Test
echo -e "${GREEN}Rust Memory Usage:${NC}"
valgrind --tool=massif cargo run --release --bin safe_hex test_data.bin
ms_print massif.out.* > rust_memory.txt

# CPU Usage Test
echo -e "${YELLOW}Testing CPU usage...${NC}"

# C++ CPU Test
echo -e "${GREEN}C++ CPU Usage:${NC}"
perf stat ./cpp_hex_tuner test_data.bin 2> cpp_cpu.txt

# Rust CPU Test
echo -e "${GREEN}Rust CPU Usage:${NC}"
perf stat cargo run --release --bin safe_hex test_data.bin 2> rust_cpu.txt

# Generate Report
echo -e "${YELLOW}Generating performance report...${NC}"

cat << EOF > performance_report.md
# ECU Tuning Interface Performance Report

## Test Parameters
- Iterations: $ITERATIONS
- File Size: $FILE_SIZE bytes
- Thread Counts: ${THREAD_COUNTS[@]}

## C++ Performance
\`\`\`
$(cat cpp_cpu.txt)
\`\`\`

## Rust Performance
\`\`\`
$(cat rust_cpu.txt)
\`\`\`

## Memory Usage
### C++
\`\`\`
$(cat cpp_memory.txt)
\`\`\`

### Rust
\`\`\`
$(cat rust_memory.txt)
\`\`\`
EOF

# Cleanup
echo -e "${YELLOW}Cleaning up...${NC}"
rm test_data.bin
rm massif.out.*
rm cpp_memory.txt rust_memory.txt
rm cpp_cpu.txt rust_cpu.txt

echo -e "${GREEN}Performance testing complete!${NC}"
echo -e "Results saved to performance_report.md" 