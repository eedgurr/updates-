#!/bin/bash

# Exit on error
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Create backup
create_backup() {
    print_status "Creating backup..."
    BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    
    # Create backup archive
    tar -czf "$BACKUP_DIR/project_backup.tar.gz" \
        src/ \
        docs/ \
        tests/ \
        config/ \
        scripts/ \
        CMakeLists.txt \
        LICENSE \
        README.md \
        project.json \
        build.sh \
        package.sh
    
    print_status "Backup created at $BACKUP_DIR/project_backup.tar.gz"
}

# Clean up demo directories
cleanup_demos() {
    print_status "Cleaning up demo directories..."
    rm -rf demos/
    rm -rf race_car/
    rm -rf cross-platform-demos/
}

# Clean up build artifacts
cleanup_build() {
    print_status "Cleaning up build artifacts..."
    rm -rf .vscode/
    rm -rf build/
    rm -f *.o
    rm -f *.a
    rm -f *.so
    rm -f *.dll
    rm -f *.exe
    rm -f *.obj
    rm -f *.lib
    rm -f *.pdb
    rm -f *.ilk
    rm -f *.exp
    rm -f *.idb
}

# Clean up configuration files
cleanup_config() {
    print_status "Cleaning up configuration files..."
    rm -f .gitignore
    rm -f .vscode/extensions.json
    rm -f .DS_Store
    rm -f Thumbs.db
    rm -f *.user
    rm -f *.suo
    rm -f *.sdf
    rm -f *.opensdf
    rm -f *.VC.db
    rm -f *.VC.opendb
}

# Clean up demo files
cleanup_demo_files() {
    print_status "Cleaning up demo files..."
    rm -f demos/csharp/visualization/TuningInterface.cs
    rm -f demos/rust/safe_hex/Cargo.toml
    rm -f demos/rust/safe_hex/src/main.rs
}

# Clean up temporary files
cleanup_temp() {
    print_status "Cleaning up temporary files..."
    find . -name "*.tmp" -type f -delete
    find . -name "*.temp" -type f -delete
    find . -name "*.log" -type f -delete
    find . -name "*.bak" -type f -delete
    find . -name "*~" -type f -delete
}

# Clean up documentation
cleanup_docs() {
    print_status "Cleaning up documentation..."
    find docs/ -name "*.old" -type f -delete
    find docs/ -name "*.bak" -type f -delete
    find docs/ -name "*.tmp" -type f -delete
}

# Clean up test artifacts
cleanup_tests() {
    print_status "Cleaning up test artifacts..."
    find tests/ -name "*.o" -type f -delete
    find tests/ -name "*.exe" -type f -delete
    find tests/ -name "*.out" -type f -delete
    find tests/ -name "*.log" -type f -delete
}

# Verify cleanup
verify_cleanup() {
    print_status "Verifying cleanup..."
    
    # Check for remaining demo directories
    if [ -d "demos" ] || [ -d "race_car" ] || [ -d "cross-platform-demos" ]; then
        print_warning "Some demo directories still exist"
    fi
    
    # Check for remaining build artifacts
    if [ -d ".vscode" ] || [ -d "build" ]; then
        print_warning "Some build artifacts still exist"
    fi
    
    # Check for remaining temporary files
    if find . -name "*.tmp" -o -name "*.temp" -o -name "*.log" -o -name "*.bak" | grep -q .; then
        print_warning "Some temporary files still exist"
    fi
}

# Main cleanup function
main() {
    print_status "Starting cleanup..."
    
    # Create backup first
    create_backup
    
    # Run all cleanup functions
    cleanup_demos
    cleanup_build
    cleanup_config
    cleanup_demo_files
    cleanup_temp
    cleanup_docs
    cleanup_tests
    
    # Verify cleanup
    verify_cleanup
    
    print_status "Cleanup completed!"
}

# Run main function
main 