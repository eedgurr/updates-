#!/bin/bash

# EFI Science Installation Script for macOS and Linux
# This script installs all required components for EFI Science development

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to detect OS
detect_os() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    elif [[ -f /etc/debian_version ]]; then
        echo "debian"
    elif [[ -f /etc/redhat-release ]]; then
        echo "redhat"
    else
        echo "unknown"
    fi
}

# Function to install package manager
install_package_manager() {
    local os=$(detect_os)
    
    case $os in
        "macos")
            if ! command_exists brew; then
                echo "Installing Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            ;;
        "debian")
            if ! command_exists apt; then
                echo "Error: apt not found"
                exit 1
            fi
            sudo apt update
            ;;
        "redhat")
            if ! command_exists dnf; then
                echo "Error: dnf not found"
                exit 1
            fi
            sudo dnf update
            ;;
        *)
            echo "Unsupported OS"
            exit 1
            ;;
    esac
}

# Function to install package
install_package() {
    local os=$(detect_os)
    local package=$1
    
    case $os in
        "macos")
            brew install $package
            ;;
        "debian")
            sudo apt install -y $package
            ;;
        "redhat")
            sudo dnf install -y $package
            ;;
    esac
}

# Function to install C/C++ tools
install_cpp_tools() {
    echo "Installing C/C++ development tools..."
    
    local os=$(detect_os)
    case $os in
        "macos")
            brew install cmake gcc gdb
            ;;
        "debian")
            install_package "build-essential cmake gdb"
            ;;
        "redhat")
            install_package "gcc-c++ cmake gdb"
            ;;
    esac
}

# Function to install .NET SDK
install_dotnet() {
    echo "Installing .NET SDK..."
    
    if ! command_exists dotnet; then
        local os=$(detect_os)
        case $os in
            "macos")
                brew install dotnet
                ;;
            "debian")
                wget https://packages.microsoft.com/config/debian/11/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
                sudo dpkg -i packages-microsoft-prod.deb
                sudo apt update
                sudo apt install -y dotnet-sdk-6.0
                ;;
            "redhat")
                sudo rpm -Uvh https://packages.microsoft.com/config/rhel/7/packages-microsoft-prod.rpm
                sudo dnf install -y dotnet-sdk-6.0
                ;;
        esac
    fi
}

# Function to install Python
install_python() {
    echo "Installing Python..."
    
    local os=$(detect_os)
    case $os in
        "macos")
            brew install python
            ;;
        "debian")
            install_package "python3 python3-pip python3-venv"
            ;;
        "redhat")
            install_package "python3 python3-pip"
            ;;
    esac
    
    # Install required Python packages
    pip3 install numpy pandas matplotlib jupyter
}

# Function to install Rust
install_rust() {
    echo "Installing Rust..."
    
    if ! command_exists rustc; then
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
        source $HOME/.cargo/env
    fi
}

# Function to install Git
install_git() {
    echo "Installing Git..."
    
    if ! command_exists git; then
        install_package "git"
    fi
}

# Function to install OBD2 tools
install_obd2_tools() {
    echo "Installing OBD2 tools..."
    pip3 install obd
}

# Main installation process
echo "Starting EFI Science installation..."

# Install package manager
install_package_manager

# Install required components
install_cpp_tools
install_dotnet
install_python
install_rust
install_git
install_obd2_tools

# Create development directories
mkdir -p cpp csharp python rust docs scripts tools

# Clone repository
if [ ! -d .git ]; then
    echo "Cloning EFI Science repository..."
    git clone https://github.com/yourusername/efi-science.git .
fi

echo "Installation completed successfully!"
echo "Please restart your terminal to ensure all components are properly installed." 