#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Function to print info
print_info() {
    echo -e "${BLUE}[i] $1${NC}"
}

# Function to clean build artifacts
clean_repo() {
    local repo_dir=$1
    print_info "Cleaning $repo_dir..."
    
    # Remove build directories
    rm -rf "$repo_dir/build"
    rm -rf "$repo_dir/bin"
    rm -rf "$repo_dir/obj"
    
    # Remove IDE files
    rm -rf "$repo_dir/.vs"
    rm -rf "$repo_dir/.vscode"
    rm -rf "$repo_dir/.idea"
    
    # Remove temporary files
    find "$repo_dir" -name "*.tmp" -delete
    find "$repo_dir" -name "*.temp" -delete
    find "$repo_dir" -name "*.log" -delete
    find "$repo_dir" -name "*.bak" -delete
    find "$repo_dir" -name "*~" -delete
}

# Main function
main() {
    print_status "Starting project organization..."
    
    # Create target directory in Downloads
    local target_dir="$HOME/Downloads/ecu-tuning-projects"
    print_info "Creating directory: $target_dir"
    mkdir -p "$target_dir"
    
    # Clean each repository
    clean_repo "ecu-core"
    clean_repo "ecu-efficiency"
    clean_repo "ecu-scaling"
    clean_repo "ecu-maui"
    
    # Copy repositories to target directory
    print_info "Copying repositories..."
    cp -r ecu-core "$target_dir/"
    cp -r ecu-efficiency "$target_dir/"
    cp -r ecu-scaling "$target_dir/"
    cp -r ecu-maui "$target_dir/"
    cp -r scripts "$target_dir/"
    cp README.md "$target_dir/"
    
    # Create a README in the target directory
    cat > "$target_dir/README.md" << EOL
# ECU Tuning Projects

This directory contains the following projects:

1. **ecu-core**: Core ECU communication library
   - Basic ECU communication
   - Safety features
   - Cross-platform support

2. **ecu-efficiency**: Engine efficiency calculations
   - VE calculations
   - Air flow modeling
   - Temperature compensation

3. **ecu-scaling**: Map scaling and optimization
   - Map scaling algorithms
   - Interpolation methods
   - Table optimization

4. **ecu-maui**: Cross-platform MAUI application
   - Real-time monitoring
   - Map editing interface
   - Data logging

## Building the Projects

### C++ Projects (ecu-core, ecu-efficiency, ecu-scaling)
\`\`\`bash
cd <project-directory>
mkdir build && cd build
cmake ..
cmake --build .
\`\`\`

### MAUI Project (ecu-maui)
\`\`\`bash
cd ecu-maui
dotnet build
\`\`\`

## Uploading to GitHub
1. Create repositories on GitHub
2. Initialize git in each project directory
3. Add remote and push:
   \`\`\`bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/yourusername/repo-name.git
   git push -u origin main
   \`\`\`
EOL
    
    # Create zip file with specified name
    print_info "Creating zip file: cashout828app.zip"
    cd "$HOME/Downloads"
    zip -r "cashout828app.zip" "ecu-tuning-projects"
    
    if [ $? -eq 0 ]; then
        print_status "Successfully created cashout828app.zip in Downloads"
        print_info "You can now upload this zip file to GitHub"
    else
        print_error "Failed to create zip file"
    fi
}

# Run main function
main 