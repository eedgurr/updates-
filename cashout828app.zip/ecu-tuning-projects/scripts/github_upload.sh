#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Function to print info
print_info() {
    echo -e "${BLUE}[i] $1${NC}"
}

# Function to initialize git repository
init_repo() {
    local repo_name=$1
    local repo_dir=$2
    
    print_info "Initializing $repo_name..."
    
    cd "$repo_dir" || exit 1
    
    # Initialize git
    git init
    
    # Create .gitignore
    cat > .gitignore << EOL
# Build artifacts
build/
*.o
*.a
*.so
*.dll
*.exe
*.obj
*.lib
*.pdb
*.ilk
*.exp
*.idb

# IDE files
.vs/
.vscode/
*.swp
*.swo
*~

# Temporary files
*.tmp
*.temp
*.log
*.bak

# OS files
.DS_Store
Thumbs.db
desktop.ini

# Dependencies
node_modules/
vendor/
EOL
    
    # Add all files
    git add .
    
    # Initial commit
    git commit -m "Initial commit"
    
    print_status "$repo_name initialized"
}

# Main function
main() {
    print_status "Starting repository initialization..."
    
    # Initialize each repository
    init_repo "ECU Core" "ecu-core"
    init_repo "ECU Efficiency" "ecu-efficiency"
    init_repo "ECU Scaling" "ecu-scaling"
    init_repo "ECU MAUI" "ecu-maui"
    
    print_status "\nRepository initialization completed!"
    print_info "\nTo upload to GitHub:"
    print_info "1. Create repositories on GitHub"
    print_info "2. Add remotes:"
    print_info "   git remote add origin https://github.com/yourusername/repo-name.git"
    print_info "3. Push:"
    print_info "   git push -u origin main"
}

# Run main function
main 