#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Function to print info
print_info() {
    echo -e "${BLUE}[i] $1${NC}"
}

# Function to get size of files/directories
get_size() {
    du -sh "$1" 2>/dev/null | cut -f1
}

# Function to format size in human readable format
format_size() {
    local size=$1
    local units=("B" "K" "M" "G" "T")
    local unit=0
    
    while [ $size -ge 1024 ] && [ $unit -lt ${#units[@]} ]; do
        size=$((size / 1024))
        unit=$((unit + 1))
    done
    
    echo "${size}${units[$unit]}"
}

# Function to analyze demo directories
analyze_demos() {
    print_info "\nAnalyzing demo directories..."
    local total_size=0
    
    if [ -d "demos" ]; then
        size=$(get_size "demos")
        print_info "demos/: $size"
        total_size=$((total_size + $(du -sk "demos" 2>/dev/null | cut -f1)))
    fi
    
    if [ -d "race_car" ]; then
        size=$(get_size "race_car")
        print_info "race_car/: $size"
        total_size=$((total_size + $(du -sk "race_car" 2>/dev/null | cut -f1)))
    fi
    
    if [ -d "cross-platform-demos" ]; then
        size=$(get_size "cross-platform-demos")
        print_info "cross-platform-demos/: $size"
        total_size=$((total_size + $(du -sk "cross-platform-demos" 2>/dev/null | cut -f1)))
    fi
    
    echo "Total demo size: $(format_size $((total_size * 1024)))"
}

# Function to analyze build artifacts
analyze_build() {
    print_info "\nAnalyzing build artifacts..."
    local total_size=0
    
    if [ -d ".vscode" ]; then
        size=$(get_size ".vscode")
        print_info ".vscode/: $size"
        total_size=$((total_size + $(du -sk ".vscode" 2>/dev/null | cut -f1)))
    fi
    
    if [ -d "build" ]; then
        size=$(get_size "build")
        print_info "build/: $size"
        total_size=$((total_size + $(du -sk "build" 2>/dev/null | cut -f1)))
    fi
    
    # Count object files
    obj_files=$(find . -name "*.o" -o -name "*.a" -o -name "*.so" -o -name "*.dll" -o -name "*.exe" -o -name "*.obj" -o -name "*.lib" -o -name "*.pdb" -o -name "*.ilk" -o -name "*.exp" -o -name "*.idb" 2>/dev/null | wc -l)
    if [ $obj_files -gt 0 ]; then
        print_info "Found $obj_files object files"
        total_size=$((total_size + $(find . -name "*.o" -o -name "*.a" -o -name "*.so" -o -name "*.dll" -o -name "*.exe" -o -name "*.obj" -o -name "*.lib" -o -name "*.pdb" -o -name "*.ilk" -o -name "*.exp" -o -name "*.idb" -type f -exec du -ck {} + 2>/dev/null | tail -n1 | cut -f1)))
    fi
    
    echo "Total build artifacts size: $(format_size $((total_size * 1024)))"
}

# Function to analyze temporary files
analyze_temp() {
    print_info "\nAnalyzing temporary files..."
    local total_size=0
    
    # Count temporary files
    temp_files=$(find . -name "*.tmp" -o -name "*.temp" -o -name "*.log" -o -name "*.bak" -o -name "*~" 2>/dev/null | wc -l)
    if [ $temp_files -gt 0 ]; then
        print_info "Found $temp_files temporary files"
        total_size=$((total_size + $(find . -name "*.tmp" -o -name "*.temp" -o -name "*.log" -o -name "*.bak" -o -name "*~" -type f -exec du -ck {} + 2>/dev/null | tail -n1 | cut -f1)))
    fi
    
    echo "Total temporary files size: $(format_size $((total_size * 1024)))"
}

# Function to analyze test artifacts
analyze_tests() {
    print_info "\nAnalyzing test artifacts..."
    local total_size=0
    
    if [ -d "tests" ]; then
        test_files=$(find tests/ -name "*.o" -o -name "*.exe" -o -name "*.out" -o -name "*.log" 2>/dev/null | wc -l)
        if [ $test_files -gt 0 ]; then
            print_info "Found $test_files test artifacts"
            total_size=$((total_size + $(find tests/ -name "*.o" -o -name "*.exe" -o -name "*.out" -o -name "*.log" -type f -exec du -ck {} + 2>/dev/null | tail -n1 | cut -f1)))
        fi
    fi
    
    echo "Total test artifacts size: $(format_size $((total_size * 1024)))"
}

# Function to create backup
create_backup() {
    print_info "\nCreating backup..."
    local backup_name="ecu-tuning-interface-backup-$(date +%Y%m%d).tar.gz"
    tar -czf "$backup_name" * .[^.]* 2>/dev/null
    if [ $? -eq 0 ]; then
        print_status "Backup created: $backup_name"
    else
        print_error "Failed to create backup"
    fi
}

# Main analysis function
main() {
    print_status "Starting cleanup analysis..."
    
    # Create backup first
    create_backup
    
    # Get total project size
    total_size=$(du -sk . 2>/dev/null | cut -f1)
    print_info "\nTotal project size: $(format_size $((total_size * 1024)))"
    
    # Analyze each category
    analyze_demos
    analyze_build
    analyze_temp
    analyze_tests
    
    print_status "\nAnalysis completed!"
}

# Run main function
main 