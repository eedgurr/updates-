# EFI Science Installation Script for Windows
# This script installs all required components for EFI Science development

# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "Please run this script as Administrator" -ForegroundColor Red
    exit
}

# Function to check if a command exists
function Test-Command($cmdname) {
    return [bool](Get-Command -Name $cmdname -ErrorAction SilentlyContinue)
}

# Function to install Chocolatey package
function Install-ChocolateyPackage {
    param (
        [string]$PackageName,
        [string]$PackageVersion = ""
    )
    
    if (-not (Test-Command choco)) {
        Write-Host "Installing Chocolatey package manager..."
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
    }
    
    if ($PackageVersion -eq "") {
        choco install $PackageName -y
    } else {
        choco install $PackageName --version $PackageVersion -y
    }
}

# Function to install Visual Studio components
function Install-VisualStudioComponents {
    Write-Host "Installing Visual Studio components..."
    
    # Install Visual Studio Build Tools
    Install-ChocolateyPackage "visualstudio2019buildtools"
    
    # Install Visual Studio Workloads
    $workloads = @(
        "Microsoft.VisualStudio.Workload.VCTools",
        "Microsoft.VisualStudio.Workload.ManagedDesktop",
        "Microsoft.VisualStudio.Workload.NetCoreTools"
    )
    
    foreach ($workload in $workloads) {
        Install-ChocolateyPackage "visualstudio2019-workload-$workload"
    }
}

# Function to install .NET SDK
function Install-DotNetSDK {
    Write-Host "Installing .NET SDK..."
    Install-ChocolateyPackage "dotnet-sdk"
}

# Function to install Python
function Install-Python {
    Write-Host "Installing Python..."
    Install-ChocolateyPackage "python"
    
    # Install required Python packages
    pip install numpy pandas matplotlib jupyter
}

# Function to install Rust
function Install-Rust {
    Write-Host "Installing Rust..."
    Install-ChocolateyPackage "rust"
}

# Function to install Git
function Install-Git {
    Write-Host "Installing Git..."
    Install-ChocolateyPackage "git"
}

# Function to install OBD2 tools
function Install-OBD2Tools {
    Write-Host "Installing OBD2 tools..."
    Install-ChocolateyPackage "python-obd"
}

# Main installation process
Write-Host "Starting EFI Science installation..." -ForegroundColor Green

# Install Chocolatey
if (-not (Test-Command choco)) {
    Write-Host "Installing Chocolatey package manager..."
    Set-ExecutionPolicy Bypass -Scope Process -Force
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
    Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
}

# Install required components
Install-VisualStudioComponents
Install-DotNetSDK
Install-Python
Install-Rust
Install-Git
Install-OBD2Tools

# Create development directories
$devDirs = @(
    "cpp",
    "csharp",
    "python",
    "rust",
    "docs",
    "scripts",
    "tools"
)

foreach ($dir in $devDirs) {
    New-Item -ItemType Directory -Force -Path $dir
}

# Clone repository
if (-not (Test-Path ".git")) {
    Write-Host "Cloning EFI Science repository..."
    git clone https://github.com/yourusername/efi-science.git .
}

Write-Host "Installation completed successfully!" -ForegroundColor Green
Write-Host "Please restart your computer to ensure all components are properly installed." 