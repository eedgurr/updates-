#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[!] $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}[-] $1${NC}"
}

# Function to print info
print_info() {
    echo -e "${BLUE}[i] $1${NC}"
}

# Function to clean build artifacts
clean_repo() {
    local repo_dir=$1
    print_info "Cleaning $repo_dir..."
    
    # Remove build directories
    rm -rf "$repo_dir/build"
    rm -rf "$repo_dir/bin"
    rm -rf "$repo_dir/obj"
    
    # Remove IDE files
    rm -rf "$repo_dir/.vs"
    rm -rf "$repo_dir/.vscode"
    rm -rf "$repo_dir/.idea"
    
    # Remove temporary files
    find "$repo_dir" -name "*.tmp" -delete
    find "$repo_dir" -name "*.temp" -delete
    find "$repo_dir" -name "*.log" -delete
    find "$repo_dir" -name "*.bak" -delete
    find "$repo_dir" -name "*~" -delete
}

# Main function
main() {
    print_status "Starting repository packaging..."
    
    # Clean each repository
    clean_repo "ecu-core"
    clean_repo "ecu-efficiency"
    clean_repo "ecu-scaling"
    clean_repo "ecu-maui"
    
    # Create zip file
    local zip_name="ecu-tuning-repositories-$(date +%Y%m%d).zip"
    print_info "Creating zip file: $zip_name"
    
    zip -r "$zip_name" \
        ecu-core \
        ecu-efficiency \
        ecu-scaling \
        ecu-maui \
        scripts \
        README.md
    
    if [ $? -eq 0 ]; then
        print_status "Successfully created $zip_name"
        print_info "Size: $(du -h "$zip_name" | cut -f1)"
    else
        print_error "Failed to create zip file"
    fi
}

# Run main function
main 